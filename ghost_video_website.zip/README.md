Ghost Video — Static Website
============================

This is a simple static landing page for Ghost Video.

To host:
- You can upload the contents of this folder to Netlify, Vercel, GitHub Pages or any static hosting provider.
- The site includes 'assets/logo.png' and 'assets/splash.png' (the images generated earlier).

Files:
- index.html
- styles.css
- assets/logo.png
- assets/splash.png
